# CloudBase 部署说明

## 环境变量配置

在 CloudBase 控制台 → 环境配置 → 变量配置中添加：

### 邮件备份配置（可选）
```
MAIL_USER=your-email@qq.com
MAIL_PASS=your-qq-authorization-code
MAIL_FROM=your-email@qq.com
MAIL_TO=your-email@qq.com
```

### 其他配置
```
NODE_ENV=production
CLOUDBASE_ENV=true
```

## 部署步骤

1. 将此目录上传到 CloudBase 云托管
2. 在 CloudBase 控制台配置环境变量
3. 启动服务（端口：80）

## 数据库说明

- 数据库文件路径：`api/dev.db`
- 生产环境数据存储在容器内，重启后会丢失
- 建议开启持久化存储或使用邮件备份功能
